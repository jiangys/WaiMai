﻿namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// GETS OpenId Data Format
    /// </summary>
    public class OpenIdResponse
    {
        /// <summary>
        /// 调用凭证
        /// </summary>
        public string AccessToken { get; set; }

        /// <summary>
        /// 第三方登录用户OpenId
        /// </summary>
        public string OpenId { get; set; }
    }
}
