﻿namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// 第三方登录平台配置
    /// </summary>
    public class ExternalAuthenticationConfig
    {
        /// <summary>
        /// Get AppId
        /// </summary>
        public string AppId { get; set; }

        /// <summary>
        /// Get AppKey
        /// </summary>
        public string AppKey { get; set; }

        /// <summary>
        /// Get the AuthorizationCode Url
        /// </summary>
        public string AuthorizationCodeUrl { get; set; }

        /// <summary>
        /// Get the AccessToken Url
        /// </summary>
        public string AccessTokenUrl { get; set; }

        /// <summary>
        /// Get the OpenID Url
        /// </summary>
        public string OpenIdUrl { get; set; }

        /// <summary>
        /// Get the UserInfo Url
        /// </summary>
        public string UserInfoUrl { get; set; }

        /// <summary>
        /// Get CallBack Url
        /// </summary>
        public string CallBackUrl { get; set; }

        /// <summary>
        /// Get Timeout
        /// </summary>
        public int Timeout { get; set; }
    }
}
