﻿namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// 第三方联合登录客户端, 如:QQ,微信和新浪, 用于联合登陆
    /// </summary>
    public abstract class IExternalAuthentication
    {
        /// <summary>
        /// AuthorizationCode 认证服务基地址
        /// </summary>
        public string CodeUrl { get; private set; }

        /// <summary>
        /// AccessToken 认证服务基地址
        /// </summary>
        public string TokenUrl { get; private set; }

        /// <summary>
        /// OpenId 认证服务基地址
        /// </summary>
        public string OpenIdUrl { get; private set; }

        /// <summary>
        /// 微博应用app secret
        /// </summary>
        public string ClientSecret { get; private set; }

        /// <summary>
        /// 请求超时时间
        /// </summary>
        public int Timeout { get; private set; }

        /// <summary>
        /// 腾讯的应用Id。
        /// </summary>
        public string ClientId { get; private set; }

        /// <summary>
        /// 认证成功以后通过浏览器回调的地址，如：http://www.xxxx.com/callback
        /// </summary>
        public string CallbackUrl { get; private set; }

        /// <summary>
        /// 获取用户信息基地址
        /// </summary>
        public string UserInfoUrl { get; set; }
        
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="config"> 第三方登录平台配置 </param>
        protected IExternalAuthentication(ExternalAuthenticationConfig config)
        {
            this.CodeUrl = config.AuthorizationCodeUrl;
            this.ClientId = config.AppId;
            this.CallbackUrl = config.CallBackUrl;
            this.TokenUrl = config.AccessTokenUrl;
            this.OpenIdUrl = config.OpenIdUrl;
            this.ClientSecret = config.AppKey;
            this.UserInfoUrl = config.UserInfoUrl;
            this.Timeout = config.Timeout;
        }

        /// <summary>
        /// 构造第三方联合登陆授权页地址
        /// </summary>
        /// <param name="state">验证码（防止CSRF攻击）</param>
        /// <returns>授权页地址</returns>
        public abstract string BuildRedirectUrl(string state);

        /// <summary>
        /// 获取第三方用户id
        /// </summary>
        /// <param name="code">授权回调页参数code</param>
        /// <returns>第三方用户id</returns>
        public abstract OpenIdResponse GetOpenId(string code);

        /// <summary>
        /// 获取第三方用户昵称
        /// </summary>
        /// <param name="openIdResponse">OpenIdResponse</param>
        /// <returns>string:nickName</returns>
        public abstract string GetNickName(OpenIdResponse openIdResponse);
    }
}
