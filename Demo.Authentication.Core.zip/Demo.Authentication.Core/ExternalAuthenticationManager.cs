﻿using System.Collections.Generic;

namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// 第三方联合登录管理
    /// </summary>
    public class ExternalAuthenticationManager
    {
        /// <summary>
        /// 第三方联合登录平台处理集
        /// </summary>
        private readonly IDictionary<string, IExternalAuthentication> _externalAuthentications;

        public ExternalAuthenticationManager()
        {
            _externalAuthentications = new Dictionary<string, IExternalAuthentication>();
        }

        /// <summary>
        /// Use Baidu ExternalAuthentication
        /// </summary>
        /// <param name="config">ExternalAuthenticationConfig</param>
        public void UseBaiduAuthentication(ExternalAuthenticationConfig config)
        {
            _externalAuthentications.Add(ExternalAuthenticationType.Biadu, new BaiduAuthentication((config)));
        }

        /// <summary>
        /// Use  Weixin ExternalAuthentication
        /// </summary>
        /// <param name="config">ExternalAuthenticationConfig</param>
        public void UseWeixinAuthentication(ExternalAuthenticationConfig config)
        {
            _externalAuthentications.Add(ExternalAuthenticationType.Weixin, new WeixinAuthentication((config)));
        }

        /// <summary>
        /// Use QQ ExternalAuthentication
        /// </summary>
        /// <param name="config">ExternalAuthenticationConfig</param>
        public void UseQQAuthentication(ExternalAuthenticationConfig config)
        {
            _externalAuthentications.Add(ExternalAuthenticationType.QQ, new QQAuthentication((config)));
        }

        /// <summary>
        ///  Use Weibo ExternalAuthentication
        /// </summary>
        /// <param name="config">ExternalAuthenticationConfig</param>
        public void UseWeiboAuthentication(ExternalAuthenticationConfig config)
        {
            _externalAuthentications.Add(ExternalAuthenticationType.Weibo, new WeiboAuthentication(config));
        }

        /// <summary>
        /// Gets the ExternalAuthentication By ExternalAuthenticationType
        /// </summary>
        /// <param name="authenticationType">ExternalAuthenticationType</param>
        /// <returns>ExternalAuthentication</returns>
        public IExternalAuthentication GetExternalAuthentication(string authenticationType)
        {
            if (_externalAuthentications.ContainsKey(authenticationType))
            {
                return _externalAuthentications[authenticationType];
            }

            return null;
        }
    }
}
