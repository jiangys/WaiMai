﻿using System;
using System.Net;
using System.Text;
using Demo.ExternalAuthentication.Core.Helpers;

namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// Baidu登录授权客户端
    /// </summary>
    public class BaiduAuthentication : IExternalAuthentication
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="config">第三方登录平台配置</param>
        public BaiduAuthentication(ExternalAuthenticationConfig config)
            : base(config)
        {
        }

        /// <summary>
        /// 获取第三方用户授权地址
        /// </summary>
        /// <param name="state">该参数会在回调CallbackUrl时，传递回来，用作校验。</param>
        /// <returns>state</returns>
        public override string BuildRedirectUrl(string state)
        {
            return string.Format(
                            "{0}?response_type=code&client_id={1}&redirect_uri={2}&state={3}",
                            this.CodeUrl,
                            this.ClientId,
                            this.CallbackUrl,
                            state);
        }

        /// <summary>
        /// 获取三方平台用户Id
        /// </summary>
        /// <param name="code">回调页返回的参数code(authorization code)</param>
        /// <returns>openId</returns>
        public override OpenIdResponse GetOpenId(string code)
        {
            var accessCode = this.GetAccessCode(code);

            return this.GetOpenIdByToken(accessCode);
        }

        /// <summary>
        /// 获取百度登录用户昵称
        /// </summary>
        /// <param name="openIdResponse">OpenIdResponse</param>
        /// <returns>昵称</returns>
        public override string GetNickName(OpenIdResponse openIdResponse)
        {
            var url = string.Format(
                "{0}?access_token={1}",
               this.UserInfoUrl,
               openIdResponse.AccessToken);

            var userInfoResult = HttpHelper.HttpPost(url, this.Timeout, Encoding.UTF8);

            return HttpHelper.GetValueFromJsonString(userInfoResult.Data, "uname");
        }

        /// <summary>
        /// 请求获取授权验证 access_token
        /// </summary>
        /// <param name="code">回调页返回的参数code(authorization code)</param>
        /// <returns>code</returns>
        private string GetAccessCode(string code)
        {
            var url = string.Format(
                        "{0}?grant_type=authorization_code&client_id={1}&client_secret={2}&code={3}&redirect_uri={4}",
                        this.TokenUrl, 
                        this.ClientId, 
                        this.ClientSecret, 
                        code, 
                        this.CallbackUrl);

            var accessCodeResult = HttpHelper.HttpGet(url, this.Timeout, Encoding.UTF8);

            if (accessCodeResult.StatusCode != HttpStatusCode.OK)
            {
                throw new ApplicationException(accessCodeResult.Data);
            }

            if (accessCodeResult.Data.Contains("error_code") && accessCodeResult.Data.Contains("error_msg"))
            {
                throw new ApplicationException(accessCodeResult.Data);
            }

            return HttpHelper.GetValueFromJsonString(accessCodeResult.Data, "access_token");
        }

        /// <summary>
        /// 请求获取第三方用户Id
        /// </summary>
        /// <param name="accessToken">access_token</param>
        /// <returns>第三方用户Id</returns>
        private OpenIdResponse GetOpenIdByToken(string accessToken)
        {
            var url = string.Format("{0}?access_token={1}", this.OpenIdUrl, accessToken);
            var openIdResult = HttpHelper.HttpGet(url, this.Timeout, Encoding.UTF8);
            if (openIdResult.StatusCode != HttpStatusCode.OK)
            {
                throw new ApplicationException(openIdResult.Data);
            }

            if (openIdResult.Data.Contains("error_code") && openIdResult.Data.Contains("error_msg"))
            {
                throw new ApplicationException(openIdResult.Data);
            }

            var openOId = HttpHelper.GetValueFromJsonString(openIdResult.Data, "uid");

            return new OpenIdResponse() { OpenId = openOId, AccessToken = accessToken };
        }
    }
}
