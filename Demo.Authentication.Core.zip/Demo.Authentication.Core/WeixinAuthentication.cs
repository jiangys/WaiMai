﻿using System;
using System.Net;
using System.Text;
using Demo.ExternalAuthentication.Core.Helpers;

namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// 微信登录授权客户端 
    /// </summary>
    public class WeixinAuthentication : IExternalAuthentication
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="config">第三方登录平台配置</param>
        public WeixinAuthentication(ExternalAuthenticationConfig config)
            : base(config)
        {
        }

        /// <summary>
        /// 获取授权地址
        /// </summary>  
        /// <param name="state">该参数会在回调CallbackUrl时,传递回来,用作校验</param>
        /// <returns>授权地址</returns>
        public override string BuildRedirectUrl(string state)
        {
            return string.Format(
                            "{0}?response_type=code&appid={1}&redirect_uri={2}&scope=snsapi_login&state={3}",
                            this.CodeUrl, 
                            this.ClientId, 
                            this.CallbackUrl, 
                            state);
        }

        /// <summary>
        /// 获取第三方用户id
        /// </summary>
        /// <param name="code">授权回调页参数 code(authorization code)</param>
        /// <returns>第三方用户Id</returns>
        public override OpenIdResponse GetOpenId(string code)
        {
            return this.GetOpenIdCode(code);
        }

        /// <summary>
        /// 获取微信登录用户昵称
        /// </summary>
        /// <param name="openIdResponse">OpenIdResponse</param>
        /// <returns>昵称</returns>
        public override string GetNickName(OpenIdResponse openIdResponse)
        {
            var url = string.Format(
                "{0}?access_token={1}&openid={2}",
                this.UserInfoUrl, 
                openIdResponse.AccessToken, 
                openIdResponse.OpenId);

            var userInfoResult = HttpHelper.HttpGet(url, this.Timeout, Encoding.UTF8);

            return HttpHelper.GetValueFromJsonString(userInfoResult.Data, "nickname");
        }

        /// <summary>
        /// 请求获取第三方用户Id
        /// </summary>
        /// <param name="code">code</param>
        /// <returns>第三方用户Id</returns>
        private OpenIdResponse GetOpenIdCode(string code)
        {
            var url = string.Format(
                "{0}?grant_type=authorization_code&appid={1}&secret={2}&code={3}",
                this.TokenUrl, 
                this.ClientId, 
                this.ClientSecret, 
                code);
            var accessCodeResult = HttpHelper.HttpGet(url, this.Timeout, Encoding.UTF8);

            if (accessCodeResult.StatusCode != HttpStatusCode.OK)
            {
                throw new ApplicationException(accessCodeResult.Data);
            }

            if (accessCodeResult.Data.Contains("errcode") && accessCodeResult.Data.Contains("errmsg"))
            {
                throw new ApplicationException(accessCodeResult.Data);
            }

            var openId = HttpHelper.GetValueFromJsonString(accessCodeResult.Data, "openid");
            var accessToken = HttpHelper.GetValueFromJsonString(accessCodeResult.Data, "access_token");

            return new OpenIdResponse() { OpenId = openId, AccessToken = accessToken };
        }
    }
}
