﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace Demo.ExternalAuthentication.Core.Helpers
{
    /// <summary>
    /// Http请求及结果解析
    /// </summary>
    internal sealed class HttpHelper
    {
        /// <summary>
        /// http get 请求操作
        /// </summary>
        /// <param name="url">get 地址</param>
        /// <param name="timeout">caoshi</param>
        /// <param name="encoding">编码</param>
        /// <returns>HttptResult</returns>
        public static HttpResult HttpGet(string url, int timeout, Encoding encoding = null)
        {
            var httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
            if (httpWebRequest == null)
            {
                throw new ApplicationException("请求初始化异常");
            }

            httpWebRequest.Method = "GET";
            httpWebRequest.Timeout = timeout;
            
            var httpReponse = httpWebRequest.GetResponse() as HttpWebResponse;

            string resultData = string.Empty;
            if (httpReponse.StatusCode == HttpStatusCode.OK)
            {
                var resultStream = new StreamReader(httpReponse.GetResponseStream(), encoding ?? Encoding.UTF8);
                resultData = resultStream.ReadToEnd();
                resultStream.Close();
            }

            return new HttpResult(httpReponse.StatusCode, resultData);
        }

        /// <summary>
        /// http post 请求操作
        /// </summary>
        /// <param name="url">post 地址</param>
        /// <param name="timeout">超时时间</param>
        /// <param name="encoding">编码</param>
        /// <returns>HttptResult</returns>
        public static HttpResult HttpPost(string url, int timeout, Encoding encoding = null)
        {
            var httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
            if (httpWebRequest == null)
            {
                throw new Exception("请求初始化异常");
            }

            httpWebRequest.Method = "POST";
            httpWebRequest.Timeout = timeout;
            httpWebRequest.ContentType = "application/x-www-form-urlencoded";
            var httpReponse = httpWebRequest.GetResponse() as HttpWebResponse;

            string resultData = string.Empty;
            if (httpReponse.StatusCode == HttpStatusCode.OK)
            {
                var resultStream = new StreamReader(httpReponse.GetResponseStream(), encoding ?? Encoding.UTF8);
                resultData = resultStream.ReadToEnd();
                resultStream.Close();
            }

            return new HttpResult(httpReponse.StatusCode, resultData);
        }

        /// <summary>
        /// 字符串转化为key-value字典 根据key获取value
        /// </summary>
        /// <param name="queryString">格式: access_token=dgerjge & expires_in=12345</param>
        /// <param name="key">key</param>
        /// <returns>value</returns>
        public static string GetQueryStringValue(string queryString, string key)
        {
            var queryStringParams = GetQueryStringParams(queryString);
            if (queryStringParams.ContainsKey(key))
            {
                return queryStringParams[key];
            }

            return null;
        }

        /// <summary>
        /// 字符串转化为key-value字典
        /// </summary>
        /// <param name="queryString">格式如:access_token=dfwkhtrwew & expires_in=sfwefwfsdf</param>
        /// <returns>key-value字典</returns>
        public static Dictionary<string, string> GetQueryStringParams(string queryString)
        {
            return queryString
                        .Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(x =>
                        {
                            var tokens = x.Split(new[] { '=' }, StringSplitOptions.RemoveEmptyEntries);
                            return new KeyValuePair<string, string>(tokens[0], tokens[1]);
                        })
                        .ToDictionary(x => x.Key, x => x.Value);
        }

        /// <summary>
        /// 字符串转成json，去除callback(),根据key获取value
        /// </summary>
        /// <param name="callbackString">示例格式:callback( {"client_id":"YOUR_APPID","openid":"YOUR_OPENID"});</param>
        /// <param name="key">key</param>
        /// <returns>value</returns>
        public static string GetValueFromCallBackString(string callbackString, string key)
        {
            string jsonString = Regex.Replace(callbackString, @"(\n*callback\(\n*)|(\)\n*;\n*)", string.Empty);
            return JObject.Parse(jsonString)[key].ToString();
        }

        /// <summary>
        /// 根据key取出json字符串中的value
        /// </summary>
        /// <param name="jsonString">json格式字符串</param>
        /// <param name="key">key</param>
        /// <returns>value</returns>
        public static string GetValueFromJsonString(string jsonString, string key)
        {
            return JObject.Parse(jsonString)[key].ToString();
        }
    }
}
