﻿using System.Net;

namespace Demo.ExternalAuthentication.Core.Helpers
{
    /// <summary>
    /// http response result
    /// </summary>
    public class HttpResult
    {
        /// <summary>
        /// HttpStatusCode
        /// </summary>
        public HttpStatusCode StatusCode { get; private set; }

        /// <summary>
        /// http data
        /// </summary>
        public string Data { get; private set; }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="statusCode">http statusCode</param>
        /// <param name="data">http result</param>
        public HttpResult(HttpStatusCode statusCode, string data)
        {
            this.StatusCode = statusCode;
            this.Data = data;
        }
    }
}
