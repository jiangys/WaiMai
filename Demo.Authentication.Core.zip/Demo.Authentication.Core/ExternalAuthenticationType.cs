namespace Demo.ExternalAuthentication.Core
{
    /// <summary>
    /// ���������ϵ�¼ƽ̨����(qq,weixin,weibo,baidu)
    /// </summary>
    public class ExternalAuthenticationType
    {
        /// <summary>
        /// value : qq 
        /// </summary>
        public const string QQ = "qq";

        /// <summary>
        /// value : weixin
        /// </summary>
        public const string Weixin = "weixin";

        /// <summary>
        /// value : weibo
        /// </summary>
        public const string Weibo = "weibo";

        /// <summary>
        /// value : baidu
        /// </summary>
        public const string Biadu = "baidu";
    }
}